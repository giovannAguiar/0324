const express = require('express');
const bodyParser = require('body-parser');
const petsController = require('./controllers/petsController');
const app = express();

// Configura o EJS como mecanismo de visualização
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended:false}));

app.get('/', petsController.getAllPets);
app.get('/add', (req,res) => res.render('add'));
app.post('/add', petsController.addPets);
app.get('/edit/:id', petsController.getPetsById);
app.post('/edit/:id', petsController.updatePets);
app.get('/dell/:id', petsController.getdeleteByPets);
app.post('/dell/:id', petsController.deletePets);

app.listen(2000, () => {
    console.log('servidor rodando na porta 2000');

});