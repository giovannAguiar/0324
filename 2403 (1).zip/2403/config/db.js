const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'pets_abandonados'
});

connection.connect((err)=>{
    if (err) {
        console.error('error ao conectar ao banco de dados: ' ,err);
    }else{
        console.log ('conectado ao banco de dados MySQL!');
    }

});

module.exports = connection;