const db = require('../config/db');
const { getAllPets, addPets, updatePets, deletePets } = require('../controllers/petsController');

const Pets = {
    getAllPets: (callback) => {
        const sql = 'SELECT * FROM  tb_pet';
        db.query(sql, (err, results) => {
            if (err) throw err;
            callback(results);
        });  
    },

    getPetsById: (id, callback) => {
        const sql = 'SELECT * FROM tb_pet WHERE id = ?';
        db.query(sql, [id], (err, result) => {
            if (err) throw err;

            console.log('getPetsById','results',result[0])
            callback(result[0]);
        });
    },

    addPets:( data, callback) => {
        const sql = 'INSERT INTO tb_pet SET ?';
        db.query(sql, data, (err, result) => {
            if (err) throw err;
            callback(result);
        });
    },

    updatePets: (id, data, callback) => {
        const sql = 'UPDATE tb_pet SET ? WHERE id = ?';
        db.query(sql,[data, id], (err, result) => {
            if (err) throw err;
            callback(result);
        });
    },

    deletePets: (id,callback) => {
        const sql = 'DELETE FROM tb_pet WHERE id = ?';
        db.query(sql,[id], (err, result) => {
            if (err) throw err;
            callback(result);
        });
    }, 

    getPetsByPetsname: (petsname, callback) => {
        const sql = 'SELECT * FROM tb_pet WHERE petsname = ?';
        db.query(sql, [petsname], (err, result) => {
            if (err) throw err;
            callback(result[0]);
        })
    }
};

module.exports = Pets;
