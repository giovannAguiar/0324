const Pets = require('../models/petsModel');

exports.getAllPets = (req, res) => {
    console.log('petsController.js','getAllPets')
    Pets.getAllPets((pets) => {
        res.render('index', {pets});
    });
};

exports.getPetsById = (req, res) => {
    const petsId = req.params.id;
    console.log('petsController.js','getPetsById',petsId)
    console.log('getAllPets',petsId)
    User.getPetsById(petsId, (pets) =>{
        res.render('edit', {pets});
    });
};

exports.getdeleteByPets = (req, res) => {
    const petsId = req.params.id;
    User.getPetsById(petsId, (pets) =>{
        res.render('dell', { pets });
    });
};

exports.addPets = (req, res) => {
    const newPets = {
        nome: req.body.nome,
        raca: req.body.raca,
        porte : req.body.porte,
        cor : req.body.cor,
        especie: req.body.especie
    };
    Pets.addPets(newPets, () => {
        res.redirect('/');
    });
};

exports.updatePets = (req, res) => {
    const petsId = req.params.id;
    const updatedPets = {
        nome: req.body.nome,
        raca: req.body.raca,
        porte : req.body.porte,
        cor : req.body.cor,
        especie: req.body.especie
    };
    Pets.updatePets(petsId, updatedPets, () => {
        res.redirect('/');
    });
};

exports.deletePets = (req, res) => {
    const petsId = req.params.id;
    Pets.deletePets(petsId, () => {
        res.redirect('/');
    });
};
